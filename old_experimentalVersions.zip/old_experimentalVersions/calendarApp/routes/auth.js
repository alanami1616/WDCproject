var express = require('express');
var router = express.Router();
var connection = require('../lib/db');

router.get('/', function(req, res, next){
    res.render('auth/login',{
        title:'Login',
        email: '',
        password: ''
    })
})

router.get('/login', function(req, res, next){
    res.render('auth/login', {
        title: 'Login',
        email: '',
        password: ''
    })
})
//authenticate
router.post('/authentication', function(req, res, next){
    var email = req.body.email;
    var password = req.body.password;
    connection.query('SELECT * FROM accounts WHERE email = ? AND password = ?', [email,password], function(err, rows, fields){
        if(err) throw err
        if(rows. length <= 0){
            req.flash('error', 'Enter correct email and password')
            res.redirect('/login')
        }
        else{
            req.session.loggedin = true;
            req.session.name = name;
            res.redirect('/home');
        }
    })
})

//display login
router.get('/register', function(req, res, next){
    res.render('auth/register', {
        title:' Registration Page',
        name: '',
        email: '',
        password: ''
    })
})
