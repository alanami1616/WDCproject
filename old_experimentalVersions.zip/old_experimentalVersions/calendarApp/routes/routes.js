var express = require('express');
var router = express.Router();
var connection = require('.../lib/db');

router.get('/', function(req, res, next));

//display page
res.render('public/index.html')