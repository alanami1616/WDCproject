console.log("program starting");
var mysql = require("mysql");

var con = mysql.createConnection({
    host: "127.0.0.1"
});

var databaseName = "calendarDB_1";

con.connect(function(err){
    console.log("create database block - BEGIN");
    if (err) throw err;
    varID=6;
    con.query("create database " + databaseName, function (err, result, fields){
        if (err) throw err;
        console.log(result);
    });
    con.end();


    console.log("CREATE DATABASE BLOCK - END");
});

console.log("end of App");