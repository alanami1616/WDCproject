
function(){
    var newInput = document.createElement('input');
    var input = document.getElementById("add");
    input.appendChild(newInput);
}