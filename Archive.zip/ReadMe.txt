(Use this and follow along with the video, this shows the intended functionality of this site)

Users
When you open the page you will be directed to the login page. (Not first shown here) 
A user can create an account using this page titled Create Your Account, but since we already have an account we will go to the normal login screen. 
This user will log in and be directed to the home page, where a functioning calendar can be found. On the left the users events are shown, which lists all the events that they are invited to as well as each event sorted into attending and not attending as shown. 
When a user clicks on an invited event the event details are shown, a button is provided for the user to check their availability on google calendar as shown, and they can then decide if they can attend or not and select the appropriate button. 
The user can create an event as shown by filling out the event information into the input fields, they can also search for users to invite to the event and add guest users emails as desired. And guest will send an email about the event they have been invited to.
The user can also manage their own information and change what information they wish, by clicking the profile icon and selecting manage details. Users can then change and view their information and click the tick box to view their password. 
The User can also log out as desired by clicking the profile button and selecting log out.

Admin
Admin may log in by clicking the admin log in page on the users login page and they will be directed to the admin log in were they can log in. 
They are then directed to the manage users and event information page where can update or change and view information as they please. 
The admin can view and update their information by clicking the profile icon and they will be directed to a page where they can view and change their information, similar to how users manage their details. 
The admin can also sign up other admins by clicking on the profile and click sign up another admin. This will direct them to a page where they can create another user by filling in the input fields and clicking the button send email which will send the new admin an email containing their randomly generated password and username to login. 
The admin can then log out by clicking the profile and selecting log out which will direct them back to the login page. 